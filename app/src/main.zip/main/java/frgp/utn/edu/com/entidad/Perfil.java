package frgp.utn.edu.com.entidad;

public class Perfil {
}
