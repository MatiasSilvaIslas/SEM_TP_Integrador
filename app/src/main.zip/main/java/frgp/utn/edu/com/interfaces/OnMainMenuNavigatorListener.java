package frgp.utn.edu.com.interfaces;

public interface OnMainMenuNavigatorListener {
    void setnavigateToMainMenu(boolean navigate);

}
