package frgp.utn.edu.com.repository;

public class UsuarioData {
}
