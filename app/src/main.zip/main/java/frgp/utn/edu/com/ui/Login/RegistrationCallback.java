package frgp.utn.edu.com.ui.Login;

public interface RegistrationCallback {
    void onSuccess();
    void onFailure(String errorMessage);
}
