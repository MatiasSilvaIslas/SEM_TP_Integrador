package frgp.utn.edu.com.utils;

public  class PutConst {
    public static final String UserKey = "UserKey";
}
